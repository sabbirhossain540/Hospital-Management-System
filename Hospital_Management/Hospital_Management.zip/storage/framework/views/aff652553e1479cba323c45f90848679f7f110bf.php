<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center mb-4 mt-4" href="<?php echo e(route('home')); ?>">
        <img src="<?php echo e(asset('img/logo.webp')); ?>" class="img-fluid rounded-circle" alt="logo" width="90" height="90">
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>

    <!-- Nav Item - Pages Collapse Menu -->
    <?php if(Auth::user()->role == "admin"): ?>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
           aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-cog"></i>
            <span>Basic Configuration</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('medicalCollege.index')); ?>">Medical College Name</a>
                <a class="collapse-item" href="<?php echo e(route('educationalQualification.index')); ?>">Educational Qualification</a>
                <a class="collapse-item" href="<?php echo e(route('specialistArea.index')); ?>">Specialist Area</a>
                <a class="collapse-item" href="<?php echo e(route('expenseCategory.index')); ?>">Expense Category</a>
            </div>
        </div>
    </li>

    <li class="nav-item <?php echo e(request()->is('userList*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('userList')); ?>">
            <i class="fas fa-users"></i>
            <span>User List</span></a>
    </li>
    <li class="nav-item <?php echo e(request()->is('doctorList*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('doctorList.index')); ?>">
            <i class="fas fa-users"></i>
            <span>Doctor List</span></a>
    </li>

    <?php endif; ?>

    <li class="nav-item <?php echo e(request()->is('patientList*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('patientList.index')); ?>">
            <i class="fas fa-users"></i>
            <span>Patient List</span></a>
    </li>

    <?php if(Auth::user()->role == "admin"): ?>
    <li class="nav-item <?php echo e(request()->is('services*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('services.index')); ?>">
            <i class="fab fa-servicestack"></i>
            <span>Service List</span></a>
    </li>
    <?php endif; ?>

    <?php if(Auth::user()->role == "admin"): ?>
    <li class="nav-item <?php echo e(request()->is('references*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('references.index')); ?>">
            <i class="fas fa-hands-helping"></i>
            <span>Reference List</span></a>
    </li>


    <li class="nav-item <?php echo e(request()->is('expenses*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('expenses.index')); ?>">
            <i class="fas fa-file-invoice"></i>
            <span>Expense List</span></a>
    </li>
    <?php endif; ?>

    <li class="nav-item <?php echo e(request()->is('invoices*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('invoices.index')); ?>">
            <i class="fas fa-file-invoice-dollar"></i>
            <span>Sales Invoice</span></a>
    </li>

    <!-- Nav Item - Utilities Collapse Menu -->
    <?php if(Auth::user()->role == "admin"): ?>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
           aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-fw fa-wrench"></i>
            <span>Report</span>
        </a>
        <div id="collapseUtilities" class="collapse <?php echo e(request()->is('getSalesReport') ? 'active' : ''); ?>" aria-labelledby="headingUtilities"
             data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('getSalesReport')); ?>">Sales report</a>
                <a class="collapse-item" href="<?php echo e(route('getServiceWiseSalesReport')); ?>">Service wise sales report</a>
                <a class="collapse-item" href="<?php echo e(route('getReferenceWiseReport')); ?>">Reference wise report</a>
                <a class="collapse-item" href="<?php echo e(route('getDoctorWiseReport')); ?>">Doctor Wise report</a>
                <a class="collapse-item" href="<?php echo e(route('getExpenseReport')); ?>">Expense report</a>
                <a class="collapse-item" href="<?php echo e(route('getCategoryWiseExpenseReport')); ?>">Category wise Exp. report</a>

            </div>
        </div>
    </li>
    <?php endif; ?>















































    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/__partial/sidebar.blade.php ENDPATH**/ ?>
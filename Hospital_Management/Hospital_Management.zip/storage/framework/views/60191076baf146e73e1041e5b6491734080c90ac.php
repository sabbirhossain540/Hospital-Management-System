

<?php $__env->startSection("content"); ?>
    <script>
        $( document ).ready(function() {
            $("#dwAddress").hide();
            $("#dwNewPatientArea").hide();

            $("#flexCheckDefault").click(function(){
                if($("#flexCheckDefault").is( ":checked" ) == true){
                    $("#dwPatient").hide();
                    $("#dwAddress").show();
                    $("#dwNewPatientArea").show();
                }else{
                    $("#dwPatient").show();
                    $("#dwAddress").hide();
                    $("#dwNewPatientArea").hide();
                }
            });
        });
    </script>

    <div class="row justify-content-md-center">
        <div class="col-md-10">
            <div class="card shadow mb-4">

                <div class="card-header py-3">
                    <div class="d-flex flex-row">
                        <div class="col-md-10">
                            <?php if(isset($referenceInfo)): ?>
                                <h6 class="m-0 font-weight-bold text-primary">Update Reference</h6>
                            <?php else: ?>
                                <h6 class="m-0 font-weight-bold text-primary">Create Invoice</h6>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">





                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="flexCheckDefault" id="patientStatusCheck" name="patientStatusCheck">
                                <label class="form-check-label" for="flexCheckDefault">
                                    <strong>New Patient</strong>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3" id="dwNewPatientArea">
                        <div class="col-md-6 mb-2">
                            <label for="remark">Patient Name</label>
                            <input type="text" name="name" id="name" class="form-control" placeholder="Enter patient fullname" value="<?php echo e(old('name')); ?>" required>
                        </div>

                        <div class="col-md-6 mb-2">
                            <label for="remark">Mobile No</label>
                            <input type="text" name="mobile_no" id="mobile_no" class="form-control" placeholder="Enter mobile No" value="<?php echo e(old('mobile_no')); ?>" required>
                        </div>

                        <div class="col-md-6 ">
                            <label for="gander">Gander</label>
                            <select name="gander" id="gander" class="form-control">
                                <option value="">Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="age">Age</label>
                            <input type="text" id="age" name="age" class="form-control" placeholder="Age">
                        </div>
                    </div>

                        <div class="row mb-3">
                            <div class="col-md-6" id="dwAddress">
                                <label for="address">Address</label>
                                <input type="text" id="address" name="address" class="form-control" placeholder="Address">
                            </div>

                            <div class="col-md-6" id="dwPatient">
                                <label for="pn">Patient Name</label>
                                <select name="pataint_id" id="pataint_id" class="form-control search-option" required>
                                    <option value="">Select Patient Name</option>
                                    <?php $__currentLoopData = $patientList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($patient->id); ?>"><?php echo e($patient->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['pataint_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label for="pn">Doctor Name</label>
                                <select name="doctor_id" id="doctor_id" class="form-control search-option" required>
                                    <option value="">Select Doctor Name</option>
                                    <?php $__currentLoopData = $doctorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($doctor->id); ?>"><?php echo e($doctor->name); ?> (<?php if(!empty($doctor->Specialist->name)): ?><?php echo e($doctor->Specialist->name); ?><?php endif; ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label for="rn">Reference No</label>
                                <select name="reference_id" id="reference_id" class="search-option form-control">
                                    <option value="">Select reference no</option>
                                    <?php $__currentLoopData = $referenceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($reference->id); ?>"><?php echo e($reference->code); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['reference_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col">
                                <label for="date">Invoice Date</label>
                                <input type="text" name="ic_date" id="ic_date" class="form-control flatPickerCustom" value="<?php echo e(date("Y-m-d")); ?>" placeholder="Invoice Date">
                                <?php $__errorArgs = ['ic_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col">
                                <label for="remark">Remark</label>
                                <input type="text" name="remark" id="remark" class="form-control">
                                <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class=" py-3">
                            <div class="d-flex flex-row">
                                <div class="col-md-10">

                                </div>
                                <div class="col-md-2" style="margin-left: 65px;">
                                    <a class="btn btn-success btn-sm " onclick="handleItem()">Add Item</a>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-bordered" id="myTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th width="25%">Service Name</th>
                                    <th width="12%">Price</th>
                                    <th width="12%">Quantity</th>
                                    <th width="11%">Discount(%)</th>
                                    <th width="10%">Sub total</th>
                                    <th width="10%">Total</th>
                                    <th width="20">Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex flex-row mb-3">
                            <div class="col-10 p-2"></div>
                            <div class="col-2 p-2">
                                <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-danger btn-sm">Cancel</a>
                                <button type="submit" class="btn btn-success btn-sm main-form-submit"><?php if(isset($referenceInfo)): ?> Update <?php else: ?> Save <?php endif; ?></button>
                            </div>
                        </div>
                    </form>



                    <!-- Modal -->


                        <div class="modal fade" id="serviceModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                            <div class="modal-dialog" style="margin-top: 90px;">
                                <div class="modal-content" style="width: 500px;">
                                        <div class="modal-body">
                                            <div class="row mb-2">
                                                <div class="col">
                                                    <input type="hidden" name="csrf-token" id="csrf-token" value="<?php echo e(csrf_token()); ?>">
                                                    <input type="hidden" name="id" id="id">
                                                    <label for="pn">Item Name</label>
                                                    <input type="hidden" name="service_name" id="service_name" class="form-control" readonly>
                                                    <select name="service_id" id="service_id" class="form-control" onchange="getProductDetails()" required>
                                                        <option value="">Select a service</option>
                                                        <?php $__currentLoopData = $serviceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col">
                                                    <label for="price">Price</label>
                                                    <input type="text" name="price" id="price" class="form-control" placeholder="0" readonly>
                                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col">
                                                    <label for="quantity">Quantity</label>
                                                    <input type="number" name="quantity" id="quantity" class="form-control" placeholder="0" onkeyup="calculatePrice()">
                                                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col">
                                                    <label for="discount">Discount(%)</label>
                                                    <input type="number" name="discount" id="discount" class="form-control" placeholder="0" onkeyup="calculatePrice()">
                                                    <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col">
                                                    <label for="total">Sub total</label>
                                                    <input type="text" name="subTotal" id="subTotal" class="form-control" placeholder="0" readonly>
                                                    <?php $__errorArgs = ['subtotal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col">
                                                    <label for="total">Total</label>
                                                    <input type="text" name="total" id="total" class="form-control" placeholder="0" readonly>
                                                    <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger btn-sm cancel-button" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-success btn-sm save-data">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>


                </div>
            </div>
        </div>
    </div>

    <script>
        $(".search-option").select2({
            tags: true
        });


        $( document ).ready(function() {
            //showDataOnGrid();
            flatpickr("#ic_date");
        });

        let arr = []
        $(".main-form-submit").click(function(event){
            event.preventDefault();
            let _token   = $("#csrf-token").val();
            let pataint_id   = $("#pataint_id").val();
            let doctor_id   = $("#doctor_id").val();
            let reference_id   = $("#reference_id").val();
            let ic_date   = $("#ic_date").val();
            let remark   = $("#remark").val();
            let paidAmount   = $("#paidAmount").val();
            let dueAmount   = $("#dueAmount").val();
            let patientStatusCheck = 0;

            if($("#flexCheckDefault").is( ":checked" ) == true){
                patientStatusCheck   = 1;
            }

            let patientName   = $("#name").val();
            let mobile_no   = $("#mobile_no").val();
            let gander   = $("#gander").val();
            let age   = $("#age").val();
            let address   = $("#address").val();


            $.ajax({
                url: "<?php echo e(route('invoices.store')); ?>",
                type:"POST",
                data:{
                    pataint_id:pataint_id,
                    doctor_id:doctor_id,
                    reference_id:reference_id,
                    ic_date:ic_date,
                    remark:remark,
                    paidAmount:paidAmount,
                    dueAmount:dueAmount,
                    patientStatusCheck:patientStatusCheck,
                    patientName:patientName,
                    mobile_no:mobile_no,
                    gander:gander,
                    age:age,
                    address:address,
                    invoice_details: arr,
                    _token: _token
                },
                success:function(response){
                    Swal.fire({
                        title: 'Invoice Created Successfully',
                        confirmButtonText: `OK`,
                    }).then((result) => {
                        window.location.href = "<?php echo e(route('invoices.index')); ?>";
                    });
                },
            });
        });
        function showDataOnGrid(){

            let totalSubTotal = 0;
            let totalDiscountAmount = 0;
            let totalPayble = 0;
            for (var i=0; i<arr.length; i++) {
                totalSubTotal = totalSubTotal + parseInt(arr[i].subTotal);
                var discounted_price = (parseInt(arr[i].subTotal) * parseInt(arr[i].discount) / 100);
                totalDiscountAmount = totalDiscountAmount + discounted_price;
                totalPayble = totalPayble + parseInt(arr[i].total);
                var row = $('<tr class="rowTrack"><td>' + arr[i].service_name+ '</td><td>' + arr[i].price + '</td><td>' + arr[i].quantity + '</td><td>' + arr[i].discount + '</td><td>' + arr[i].subTotal + '</td><td>' + arr[i].total + '</td><td><button class="btn btn-outline-danger btn-sm" onclick="handleDelete(' + arr[i].id + ')"><i class="fas fa-trash-alt"></i></button></td></tr>');
                //var row = $('<tr class="rowTrack"><td>' + arr[i].service_name+ '</td><td>' + arr[i].price + '</td><td>' + arr[i].quantity + '</td><td>' + arr[i].total + '</td><td><button class="btn btn-outline-info btn-sm" onclick="handleEdit(' + arr[i].id + ')"><i class="far fa-edit"></i></button> <button class="btn btn-outline-danger btn-sm" onclick="handleDelete(' + arr[i].id + ')"><i class="fas fa-trash-alt"></i></button></td></tr>');
                $('#myTable').append(row);
            }

            let rose = $('<tr class="rowTrack"><td class="text-right" colspan="4">Subtotal <br> +VAT TK, <br> -Discount TK <br> Payble TK. <br> Paid <br> Due Amount</td>' +
                '<td colspan="2" class="text-center">'+totalSubTotal+'<br>0 <br>'+Math.floor(totalDiscountAmount)+'<br>'+totalPayble+'<br> <input type="number" name="paidAmount" id="paidAmount" onkeyup="calculatePaidAmount('+totalPayble+')" style="width: 80px;text-align: center;border-radius: 10px;outline: none;"> <br><input type="number" name="dueAmount" id="dueAmount" readonly style="width: 80px;text-align: center;border-radius: 10px;outline: none;"></td></tr>');
            $('#myTable').append(rose);
            $('#paidAmount').val(0);
            $('#dueAmount').val(totalPayble);
        }

        function calculatePaidAmount(payble){
            let paidAmount = $("#paidAmount").val();
            if(paidAmount == ''){
                $('#paidAmount').val(0);
            }

            let remainingAmount = parseInt(payble) - parseInt(paidAmount);
             $('#dueAmount').val(remainingAmount);

            if(paidAmount == ''){
                $('#dueAmount').val(payble);
            }

        }


        function handleDelete(id){
            $('.rowTrack').remove();
            arr = arr.filter(item => item.id != id);
            showDataOnGrid();
        }
        function handleEdit(id){
            $.ajax({
                type:"GET",
                url:"<?php echo e(url('getTempServiceForEdit')); ?>/"+id,
                success: function(data) {
                    $('#serviceModal').modal('show')
                    $('#id').val(data.id);
                    $('#service_id').val(data.service_id);
                    $('#price').val(data.price);
                    $('#quantity').val(data.quantity);
                    $('#total').val(data.total);
                }
            });
        }
        function handleItem(){
            $('#serviceModal').modal('show')
        }


        function getProductDetails(){
            var service_id = $("#service_id").val();
            $.ajax({
                type:"GET",
                url:"<?php echo e(url('getServiceInfo')); ?>/"+service_id,
                success: function(data) {
                    console.log(data);
                    $('#price').val(data.price);
                    $('#service_name').val(data.name);
                    $('#quantity').val(1);
                    $('#total').val(data.price);
                    $('#subTotal').val(data.price);
                    $('#discount').val(0);
                    $('#id').val(data.id);
                }
            });
        }
        function calculatePrice(){
            var price = $("#price").val();
            var quantity = $("#quantity").val();
            var discount = $("#discount").val();
            var totalAmount = price * quantity;
            var discounted_price = totalAmount - (totalAmount * discount / 100)
            $('#subTotal').val(totalAmount);
            $('#total').val(discounted_price);
        }
        function formReset(){
            $('#service_id').val('');
            $('#price').val(0);
            $('#quantity').val(0);
            $('#total').val(0);
            $('#subTotal').val(0);
            $('#discount').val(0);
        }
        $(".save-data").click(function(event){
            event.preventDefault();
            $('.rowTrack').remove();
            let _token   = $("#csrf-token").val();
            let service_id   = $("#service_id").val();
            let price   = $("#price").val();
            let quantity   = $("#quantity").val();
            let subTotal   = $("#subTotal").val();
            let discount   = $("#discount").val();
            let total   = $("#total").val();
            let service_name   = $("#service_name").val();
            let id   = $("#id").val();
            let serviceData = {
                "id": id,
                "service_id": service_id,
                "price": price,
                "quantity": quantity,
                "discount": discount,
                "subTotal": subTotal,
                "total": total,
                "service_name":service_name
            }

            arr.push(serviceData);
            showDataOnGrid();
            formReset();
            $('.cancel-button').click();
        });

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/invoice/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection("content"); ?>

    <div class="row justify-content-md-center">
        <div class="col-md-10">
            <div class="card shadow mb-4">

                <div class="card-header py-3">
                    <div class="d-flex flex-row">
                        <div class="col-md-10">
                            <?php if(isset($referenceInfo)): ?>
                                <h6 class="m-0 font-weight-bold text-primary">Update Reference</h6>
                            <?php else: ?>
                                <h6 class="m-0 font-weight-bold text-primary">Create Reference</h6>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php if(isset($referenceInfo)): ?> <?php echo e(route('references.update',$referenceInfo->id)); ?> <?php else: ?> <?php echo e(route('references.store')); ?> <?php endif; ?>" >
                        <?php echo csrf_field(); ?>
                        <?php if(isset($referenceInfo)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="mcn">Name</label>
                                <input type="text" name="name" id="name" class="form-control" placeholder="Enter reference name" <?php if(isset($referenceInfo)): ?> value="<?php echo e($referenceInfo->name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?> <?php endif; ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col">
                                <label for="mcn">Code</label>
                                <input type="text" name="code" id="code" class="form-control" placeholder="Enter Code" <?php if(isset($referenceInfo)): ?> value="<?php echo e($referenceInfo->code); ?>" <?php else: ?> value="<?php echo e(old('code')); ?> <?php endif; ?>" required>
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="mcn">Mobile No</label>
                                <input type="number" name="mobile_no" id="mobile_no" class="form-control" placeholder="Enter mobile no" <?php if(isset($referenceInfo)): ?> value="<?php echo e($referenceInfo->mobile_no); ?>" <?php else: ?> value="<?php echo e(old('mobile_no')); ?> <?php endif; ?>" required>
                                <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col">
                                <label for="mcn">Comission (%)</label>
                                <input type="text" name="comission" id="comission" class="form-control" placeholder="Enter reference commission" <?php if(isset($referenceInfo)): ?> value="<?php echo e($referenceInfo->comission); ?>" <?php else: ?> value="<?php echo e(old('comission')); ?> <?php endif; ?>" required>
                                <?php $__errorArgs = ['comission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <div class="col">
                                <label for="address">Address</label>
                                <textarea name="address" class="form-control" id="address" cols="30" rows="5" placeholder="Address"><?php if(isset($referenceInfo)): ?> <?php echo e($referenceInfo->address); ?> <?php else: ?> <?php echo e(old('address')); ?> <?php endif; ?></textarea>
                            </div>
                        </div>
                        <div class="d-flex flex-row mb-3">
                            <div class="col-10 p-2"></div>
                            <div class="col-2 p-2">
                                <a href="<?php echo e(route('references.index')); ?>" class="btn btn-danger btn-sm">Cancel</a>
                                <button type="submit" class="btn btn-success btn-sm"><?php if(isset($referenceInfo)): ?> Update <?php else: ?> Submit <?php endif; ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/references/create.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Reference Wise Report</title>
</head>
<body>
<table>
    <tr>
        <td colspan="5"><img src="<?php echo e(public_path('img/report.webp')); ?>" style="border-radius: 45px; text-align: center;" alt="logo" width="100" height="100"></td>
        <td><h2 class="text-center">Boshundhara Clinic and Digonestic center</h2><br><p class="text-center" style="margin-top: -35px;">Hospital Road, Chapai Nawabganj Sadar</p><p class="text-center" style="margin-top: -20px;margin-bottom: 30px;">Mobile no: 01771-256625, 01761-242121 (Reception)<br> 01320-788677 (Manager)</p></td>
    </tr>
</table>

<h4 class="text-center" style="margin-top: -25px;">Reference Wise Report</h4>
<h6 class="text-center">Reference Name: <?php echo e($referelName->name); ?> (<?php echo e($referelName->code); ?>)</h6>
<h6 class="text-center mb-4">Date Range: <?php echo e($fromDate); ?> -- <?php echo e($originalToDate); ?></h6>

<table class="table table-sm table-bordered" width="100">
    <thead>
        <tr>
            <th class="text-center"  width="5%">SN</th>
            <th class="text-center"  width="10%">Date</th>
            <th class="text-center"  width="15%">IV No</th>
            <th class="text-center"  width="15%">Patient Name</th>
            <th class="text-center"  width="15%">Doctor Name</th>
            <th class="text-center"  width="5%">Sub Total</th>
            <th class="text-center"  width="5%">Discount</th>
            <th class="text-center"  width="10%">Total</th>

            <th class="text-center"  width="10%">Referal Amount</th>
            <th></th>
        </tr>


    </thead>
    <tbody>
        <?php $__currentLoopData = $recordList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($key+1); ?></td>
                <td class="text-center"><?php echo e($list->created_at->format('d/m/Y')); ?></td>
                <td class="text-center"><?php echo e($list->iv_no); ?></td>
                <td class="text-center"><?php if(!empty($list->getPatient->name)): ?><?php echo e($list->getPatient->name); ?><?php endif; ?></td>
                <td class="text-center"><?php if(!empty($list->getDoctor->name)): ?><?php echo e($list->getDoctor->name); ?><?php endif; ?></td>
                <td class="text-center"><?php echo e($list->subtotal); ?></td>
                <td class="text-center"><?php echo e($list->discount); ?></td>
                <td class="text-center"><?php echo e($list->total); ?></td>

                <td class="text-center"><?php echo e($list->referalAmount); ?></td>
                <td></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td class="text-left" colspan="4">comission: <?php echo e($finalreferelCommission); ?>%</td>
            <td style="text-align: center; font-weight: bold;">Total</td>
            <td class="text-center"><?php echo e(floor($finalTotalSubtotal)); ?></td>
            <td class="text-center"><?php echo e(floor($finalTotalDiscount)); ?></td>
            <td class="text-center"><?php echo e(floor($finalTotalAmount)); ?></td>

            <td class="text-center" colspan="2"><?php echo e(floor($finalTotalRefaralAmount)); ?></td>
            <td></td>
        </tr>

    </tbody>
</table>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/report/referenceWiseReportPdf.blade.php ENDPATH**/ ?>
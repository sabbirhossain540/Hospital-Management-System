

<?php $__env->startSection("content"); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex flex-row">
                <div class="col-md-10">
                    <h6 class="m-0 font-weight-bold text-primary">User Profile</h6>
                </div>

                <div class="col-md-2" style="margin-left: 65px;">
                    <a href="<?php echo e(route('editProfile')); ?>" class="btn btn-primary btn-sm pl-10">Edit Profile</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div class="d-flex flex-row mb-3">
                    <div class="col-3 p-2"></div>
                    <div class="col-4 p-2" style="border-right: 1px dotted black">
                        <tr>
                            <td>Name: </td>
                            <td><?php echo e($userProfile->name); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Email: </td>
                            <td><?php echo e($userProfile->email); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Username: </td>
                            <td><?php echo e($userProfile->username); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Gander: </td>
                            <td><?php echo e($userProfile->gander); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Date of Birth: </td>
                            <td><?php echo e($userProfile->date_of_birth); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Mobile No: </td>
                            <td><?php echo e($userProfile->mobile_no); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Address: </td>
                            <td><?php echo e($userProfile->address); ?></td>
                        </tr>
                        <br>
                        <?php if($userProfile->role == 'doctor'): ?>
                        <tr>
                            <td>Educational Qualification: </td>
                            <td><?php echo e($userProfile->degree); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Specialist: </td>
                            <td><?php echo e($userProfile->doctor_specialist); ?></td>
                        </tr>
                        <br>
                        <?php endif; ?>
                        <tr>
                            <td>User Role: </td>
                            <td><?php echo e($userProfile->role); ?></td>
                        </tr>
                    </div>
                    <div class="col-5 p-10">
                        <img class="img-profile rounded-circle ml-5"
                             src="<?php echo e(asset('template/img/undraw_profile.svg')); ?>" width="100" height="100" >
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/user/userProfile.blade.php ENDPATH**/ ?>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\EducationalQualification;

class Doctor extends Model
{




}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SpecialistArea extends Model
{
    protected $fillable = [
        'name'
    ];
}

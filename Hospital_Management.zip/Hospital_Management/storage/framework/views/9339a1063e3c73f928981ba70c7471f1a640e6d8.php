

<?php $__env->startSection("content"); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex flex-row">
                <div class="col-md-10">
                    <h6 class="m-0 font-weight-bold text-primary">Expense Details</h6>
                </div>
                <div class="col-md-2" style="margin-left: 65px;">
                    <a target="_blank" class="btn btn-warning btn-sm" href="<?php echo e(route('printExpanse', $expanseList->id)); ?>">Print</a>
                    <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-primary btn-sm">Back</a>
                </div>
            </div>
        </div>

        <div class="card-body" class="printScrent">
            <table class="table table-bordered table-sm text-dark">
                <tr>
                    <td width="20%" class="text-right"><strong>Exp. Voucher No</strong></td>
                    <td width="30%"><?php echo e($expanseList->exp_no); ?></td>
                    <td width="20%" class="text-right"><strong>Expanse Date</strong></td>
                    <td width="30%"><?php echo e(date_format($expanseList->formated_exp_date,'jS M, Y')); ?></td>
                </tr>
                <tr>

                    <td width="20%" class="text-right"><strong>Comments</strong></td>
                    <td width="30%"><?php echo e($expanseList->comments); ?></td>
                    <td width="20%" class="text-right"><strong>Create User</strong></td>
                    <td width="30%"><?php echo e($expanseList->getCreatedUser['name']); ?></td>
                </tr>
            </table>

            <div class="table-responsive">
                <table class="table table-bordered table-sm text-dark" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th width="5%">SN</th>
                        <th width="30%">Exp. Title</th>
                        <th width="20%">Exp. Category</th>
                        <th width="30%">Comments</th>
                        <th width="15%">Amount</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $expanseList->expenseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$expanse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($expanse->exp_title); ?></td>
                            <td><?php if(!empty($expanse->getExpCategoryName->name)): ?><?php echo e($expanse->getExpCategoryName->name); ?><?php endif; ?></td>

                            <td><?php echo e($expanse->comments); ?></td>
                            <td><?php echo e($expanse->amount); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="4" align="right">Total</td>
                            <td><?php echo e($expanseList->amount); ?></td>
                        </tr>

                    </tbody>
                </table>

        </div>
    </div>






























<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/expense/show.blade.php ENDPATH**/ ?>
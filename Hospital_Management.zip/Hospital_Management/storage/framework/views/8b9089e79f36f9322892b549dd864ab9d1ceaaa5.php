<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Sales Report</title>
</head>
<body>
<table>
    <tr>
        <td colspan="5"><img src="<?php echo e(public_path('img/report.webp')); ?>" style="border-radius: 45px; text-align: center;" alt="logo" width="100" height="100"></td>
        <td><h2 class="text-center">Boshundhara Clinic and Digonestic center</h2><br><p class="text-center" style="margin-top: -35px;">Hospital Road, Chapai Nawabganj Sadar</p><p class="text-center" style="margin-top: -20px;margin-bottom: 30px;">Mobile no: 01771-256625, 01761-242121 (Reception)<br> 01320-788677 (Manager)</p></td>
    </tr>
</table>

<h4 class="text-center" style="margin-top: -25px;">Sales Report</h4>

<h6 class="text-center mb-4">Date Range: <?php echo e($fromDate); ?> -- <?php echo e($originalToDate); ?></h6>

<table class="table table-sm table-bordered">
    <thead>
    <tr>
        <th class="text-center" scope="col">SN</th>
        <th class="text-center" scope="col">Sales Date</th>
        <th class="text-center" scope="col">Service Name</th>
        <th class="text-center" scope="col">Ref Name</th>
        <th class="text-center" scope="col">Price</th>
        <th class="text-center" scope="col">Quantity</th>
        <th class="text-center" scope="col">Sub Total</th>
        <th class="text-center" scope="col">Discount(%)</th>
        <th class="text-center" scope="col">Total</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $invoiceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($list->created_at->format('d/m/Y')); ?></td>
                <td><?php if(!empty($list->getServiceName->name)): ?><?php echo e($list->getServiceName->name); ?><?php endif; ?></td>

                <td><?php if(!empty($list->getInvoiceInfo->getReference->name)): ?><?php echo e($list->getInvoiceInfo->getReference->name); ?><?php endif; ?></td>
                <td class="text-center"><?php echo e($list->price); ?></td>
                <td class="text-center"><?php echo e($list->quantity); ?></td>
                <td class="text-center"><?php echo e($list->subtotal); ?></td>
                <td class="text-center"><?php echo e($list->discountAmount); ?>(<?php echo e($list->discount); ?>%)</td>
                <td class="text-center"><?php echo e(floor($list->total)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="4"></td>
                <td>Total</td>
                <td class="text-center"><?php echo e($totalQuantity); ?></td>
                <td class="text-center"><?php echo e($totalSubTotal); ?></td>
                <td class="text-center"><?php echo e($totalDiscount); ?></td>
                <td class="text-center"><?php echo e(floor($totalAmount)); ?></td>
            </tr>
    </tbody>
</table>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/report/salesReportPdf.blade.php ENDPATH**/ ?>
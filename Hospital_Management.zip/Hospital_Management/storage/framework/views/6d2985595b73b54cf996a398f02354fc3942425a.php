<?php echo $__env->make('admin.__partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>

                    <?php if(session()->has('warning')): ?>
                        <div class="alert alert-warning">
                            <?php echo e(session()->get('warning')); ?>

                        </div>
                    <?php endif; ?>
                <?php echo $__env->yieldContent("content"); ?>
            </div>
            <!-- /.container-fluid -->
<?php echo $__env->make('admin.__partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/layouts.blade.php ENDPATH**/ ?>
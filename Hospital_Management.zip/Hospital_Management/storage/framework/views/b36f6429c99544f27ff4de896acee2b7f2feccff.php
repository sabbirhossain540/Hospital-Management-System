

<?php $__env->startSection("content"); ?>

    <div class="row justify-content-md-center">
        <div class="col-md-10">
            <div class="card shadow mb-4">

                <div class="card-header py-3">
                    <div class="d-flex flex-row">
                        <div class="col-md-10">
                            <?php if(isset($expanceCategory)): ?>
                                <h6 class="m-0 font-weight-bold text-primary">Update Expense Category</h6>
                            <?php else: ?>
                                <h6 class="m-0 font-weight-bold text-primary">Create Expense Category</h6>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php if(isset($expanceCategory)): ?> <?php echo e(route('expenseCategory.update',$expanceCategory->id)); ?> <?php else: ?> <?php echo e(route('expenseCategory.store')); ?> <?php endif; ?>" >
                        <?php echo csrf_field(); ?>
                        <?php if(isset($expanceCategory)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="mcn">Expense Category Name</label>
                                <input type="text" name="name" id="name" class="form-control" placeholder="Enter expense category name" <?php if(isset($expanceCategory)): ?> value="<?php echo e($expanceCategory->name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?> <?php endif; ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="d-flex flex-row mb-3">
                            <div class="col-10 p-2"></div>
                            <div class="col-2 p-2">
                                <a href="<?php echo e(route('expenseCategory.index')); ?>" class="btn btn-danger btn-sm">Cancel</a>
                                <button type="submit" class="btn btn-success btn-sm"><?php if(isset($expanceCategory)): ?> Update <?php else: ?> Submit <?php endif; ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/expenseCategory/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection("content"); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex flex-row">
                <div class="col-md-10">
                    <h6 class="m-0 font-weight-bold text-primary">Doctor List</h6>
                </div>
                <div class="col-md-2" style="margin-left: 65px;">
                    <a href="<?php echo e(route('doctorList.create')); ?>" class="btn btn-primary btn-sm pl-10"><i class="fas fa-plus-square"></i> Create Doctor</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th width="5%">SN</th>
                        <th width="20%">Name</th>
                        <th width="15%">Email</th>

                        <th width="10%">Password</th>
                        <th width="10%">Mobile No</th>
                        <th width="5%">Gander</th>
                        <th width="5%">Qualification</th>
                        <th width="30%">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>

                            <td><?php echo e($user->password_ref); ?></td>
                            <td><?php echo e($user->mobile_no); ?></td>
                            <td><?php echo e($user->gander); ?></td>
                            <td><?php echo e($user->educationQualification->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('doctorList.show',$user->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo e(route('doctorList.edit',$user->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                                <button class="btn btn-danger btn-sm" onclick="handleDelete(<?php echo e($user->id); ?>)"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <!-- Modal -->
    <form action="" method="POST" id="deleteForm">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Are you sure want to delete this doctor?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success btn-sm" data-dismiss="modal">No. Go back</button>
                        <button type="submit" class="btn btn-danger btn-sm">Yes. Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable({
                "order": [[ 0, "desc" ]]
            });
        });

        function handleDelete(id){
            var form = document.getElementById('deleteForm')
            form.action = '/deleteDoctor/'+id
            //console.log(form)
            $('#deleteModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/doctor/index.blade.php ENDPATH**/ ?>
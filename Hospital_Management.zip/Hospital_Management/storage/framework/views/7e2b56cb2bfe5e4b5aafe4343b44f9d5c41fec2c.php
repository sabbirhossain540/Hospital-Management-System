

<?php $__env->startSection("content"); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex flex-row">
                <div class="col-md-10">
                    <h6 class="m-0 font-weight-bold text-primary">Patient Information</h6>
                </div>

                <div class="col-md-2" style="margin-left: 65px;">
                    <a href="<?php echo e(route('patientList.index')); ?>" class="btn btn-info btn-sm pl-10">Back to list</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div class="d-flex flex-row mb-3">
                    <div class="col-3 p-2"></div>
                    <div class="col-4 p-2" style="border-right: 1px dotted black">
                        <tr>
                            <td>Name: </td>
                            <td><?php echo e($userInfo->name); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Email: </td>
                            <td><?php echo e($userInfo->email); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Username: </td>
                            <td><?php echo e($userInfo->username); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Gander: </td>
                            <td><?php echo e($userInfo->gander); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Date of Birth: </td>
                            <td><?php echo e($userInfo->date_of_birth); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Age: </td>
                            <td><?php echo e($userInfo->age); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Mobile No: </td>
                            <td><?php echo e($userInfo->mobile_no); ?></td>
                        </tr>
                        <br>
                        <tr>
                            <td>Address: </td>
                            <td><?php echo e($userInfo->address); ?></td>
                        </tr>
                    </div>
                    <div class="col-5 p-10">
                        <img class="img-profile rounded-circle ml-5"
                             src="<?php echo e(asset('template/img/undraw_profile.svg')); ?>" width="100" height="100" >
                    </div>
                </div>

            </div>
            <h5 class="text-center mt-5 mb-3">Invoice List</h5>
            <div class="table-responsive">
                <table class="table table-bordered table-sm" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th width="5%">SN</th>
                        <th width="15%" class="sorting_desc">Invoice No</th>
                        <th width="20%">Invoice Date</th>
                        <th width="20%">Ref. Doctor</th>
                        <th width="10%">Paid Amount</th>
                        <th width="10%">Dues</th>
                        <th width="20%">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $invoiceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($invoice->iv_no); ?></td>
                            <td><?php echo e(date_format($invoice->formated_ic_date,'d-m-y')); ?></td>
                            <td><?php if(!empty($invoice->getDoctor->name)): ?><?php echo e($invoice->getDoctor->name); ?><?php endif; ?></td>
                            <td><?php echo e($invoice->paidAmount); ?></td>
                            <td><?php echo e($invoice->dueAmount); ?></td>
                            <td><a target="_blank" class="btn btn-warning btn-sm" href="<?php echo e(route('printInvoice', $invoice->id)); ?>">Invoice Print</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management-System\Hospital_Management\resources\views/admin/patient/show.blade.php ENDPATH**/ ?>
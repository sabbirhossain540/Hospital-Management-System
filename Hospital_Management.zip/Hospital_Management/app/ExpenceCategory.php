<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpenceCategory extends Model
{
    protected $fillable = [
        'name'
    ];
}

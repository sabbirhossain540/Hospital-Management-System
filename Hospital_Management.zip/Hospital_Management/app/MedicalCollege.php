<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MedicalCollege extends Model
{
    protected $fillable = [
        'name'
    ];
}
